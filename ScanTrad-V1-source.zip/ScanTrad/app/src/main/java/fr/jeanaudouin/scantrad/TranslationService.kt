package fr.jeanaudouin.scantrad

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.*
import android.os.*
import android.view.*
import androidx.core.app.NotificationCompat
import com.google.mlkit.nl.translate.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap

class TranslationService : Service() {
    companion object { const val START="scantrad.START"; const val STOP="scantrad.STOP"; const val CH="scantrad" }
    private var projection: MediaProjection?=null; private var reader: ImageReader?=null; private var display: android.hardware.display.VirtualDisplay?=null
    private lateinit var wm: WindowManager; private lateinit var overlay: TranslationOverlay
    private val recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val translator=Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.FRENCH).build())
    private val cache=ConcurrentHashMap<String,String>(); private var busy=false; private var lastHash=0L; private var lastRun=0L
    override fun onCreate(){ super.onCreate(); createChannel(); wm=getSystemService(WINDOW_SERVICE) as WindowManager; overlay=TranslationOverlay(this); translator.downloadModelIfNeeded() }
    override fun onStartCommand(intent: Intent?, flags:Int, id:Int):Int {
        if(intent?.action==STOP){ stopSelf(); return START_NOT_STICKY }
        if(intent?.action==START){ startForeground(7, notification()); val code=intent.getIntExtra("resultCode",Activity.RESULT_CANCELED); @Suppress("DEPRECATION") val data=intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY; beginProjection(code,data) }
        return START_NOT_STICKY
    }
    private fun beginProjection(code:Int,data:Intent){
        val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; projection=mgr.getMediaProjection(code,data)
        projection?.registerCallback(object:MediaProjection.Callback(){ override fun onStop(){ stopSelf() } },Handler(Looper.getMainLooper()))
        val dm=resources.displayMetrics; val w=dm.widthPixels; val h=dm.heightPixels
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2)
        display=projection?.createVirtualDisplay("ScanTrad",w,h,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,null)
        addOverlay()
        reader?.setOnImageAvailableListener({ r -> val now=System.currentTimeMillis(); if(busy || now-lastRun<650){ r.acquireLatestImage()?.close(); return@setOnImageAvailableListener }; val img=r.acquireLatestImage()?:return@setOnImageAvailableListener; val plane=img.planes[0]; val bmp=planeToBitmap(plane.buffer,plane.pixelStride,plane.rowStride,w,h); img.close(); val hash=quickHash(bmp); if(kotlin.math.abs(hash-lastHash)>8000){ lastHash=hash; lastRun=now; process(bmp) } else bmp.recycle() },Handler(Looper.getMainLooper()))
    }
    private fun planeToBitmap(buf:ByteBuffer,pixelStride:Int,rowStride:Int,w:Int,h:Int):Bitmap { val rowPadding=rowStride-pixelStride*w; val wide=w+rowPadding/pixelStride; val tmp=Bitmap.createBitmap(wide,h,Bitmap.Config.ARGB_8888); tmp.copyPixelsFromBuffer(buf); return Bitmap.createBitmap(tmp,0,0,w,h).also { if(it!==tmp) tmp.recycle() } }
    private fun quickHash(b:Bitmap):Long { var s=0L; val sx=maxOf(1,b.width/18); val sy=maxOf(1,b.height/28); for(y in 0 until b.height step sy) for(x in 0 until b.width step sx){ val c=b.getPixel(x,y); s += Color.red(c)*3L+Color.green(c)*5L+Color.blue(c)*7L }; return s }
    private fun process(bmp:Bitmap){ busy=true; recognizer.process(InputImage.fromBitmap(bmp,0)).addOnSuccessListener { result ->
        val candidates=result.textBlocks.flatMap{it.lines}.filter { it.text.length>=2 && it.boundingBox!=null }.take(30)
        if(candidates.isEmpty()){ overlay.setItems(emptyList()); busy=false; bmp.recycle(); return@addOnSuccessListener }
        val out=java.util.Collections.synchronizedList(mutableListOf<OverlayItem>()); var remaining=candidates.size
        candidates.forEach { line -> val original=line.text.trim(); val rect=line.boundingBox!!; val cached=cache[original]
            if(cached!=null){ out.add(OverlayItem(rect,cached)); if(--remaining==0) finish(out,bmp) }
            else translator.translate(original).addOnSuccessListener { fr -> cache[original]=fr; out.add(OverlayItem(rect,fr)); if(--remaining==0) finish(out,bmp) }.addOnFailureListener { if(--remaining==0) finish(out,bmp) }
        }
    }.addOnFailureListener { busy=false; bmp.recycle() } }
    private fun finish(items:List<OverlayItem>,bmp:Bitmap){ Handler(Looper.getMainLooper()).post { overlay.setItems(items); busy=false; bmp.recycle() } }
    private fun addOverlay(){ val p=WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT); p.gravity=Gravity.TOP or Gravity.START; wm.addView(overlay,p) }
    private fun notification():Notification = NotificationCompat.Builder(this,CH).setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("ScanTrad actif").setContentText("Traduction automatique anglais → français").setOngoing(true).build()
    private fun createChannel(){ if(Build.VERSION.SDK_INT>=26)(getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(CH,"ScanTrad",NotificationManager.IMPORTANCE_LOW)) }
    override fun onDestroy(){ try{wm.removeView(overlay)}catch(_:Exception){}; reader?.close(); display?.release(); projection?.stop(); recognizer.close(); translator.close(); super.onDestroy() }
    override fun onBind(i:Intent?)=null
}

data class OverlayItem(val rect:Rect,val text:String)
class TranslationOverlay(c:Context):View(c){ private var items:List<OverlayItem> = emptyList(); private val bg=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(225,255,255,255)}; private val fg=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK; textAlign=Paint.Align.CENTER; typeface=Typeface.DEFAULT_BOLD}
    fun setItems(v:List<OverlayItem>){items=v;invalidate()}
    override fun onDraw(canvas:Canvas){ super.onDraw(canvas); items.forEach { i -> val r=RectF(i.rect); r.inset(-5f,-3f); canvas.drawRoundRect(r,10f,10f,bg); var size=(r.height()*0.52f).coerceIn(11f,28f); fg.textSize=size; while(fg.measureText(i.text)>r.width()-8 && size>10){size-=1;fg.textSize=size}; val y=r.centerY()-(fg.ascent()+fg.descent())/2; canvas.drawText(i.text.take(80),r.centerX(),y,fg) } }
}
