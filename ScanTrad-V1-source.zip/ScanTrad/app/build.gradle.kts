plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "fr.jeanaudouin.scantrad"
    compileSdk = 35
    defaultConfig {
        applicationId = "fr.jeanaudouin.scantrad"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:translate:17.0.3")
}
