package fr.jeanaudouin.scantrad

import android.app.*
import android.content.*
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private val captureLauncher = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK && r.data != null) {
            val i = Intent(this, TranslationService::class.java).apply {
                action = TranslationService.START
                putExtra("resultCode", r.resultCode)
                putExtra("data", r.data)
            }
            ContextCompat.startForegroundService(this, i)
            status.text = "Traduction active — ouvre ton scan et fais défiler."
            moveTaskToBack(true)
        } else status.text = "Capture refusée."
    }
    override fun onCreate(b: Bundle?) { super.onCreate(b)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(48,48,48,48) }
        val title = TextView(this).apply { text="ScanTrad"; textSize=32f; gravity=Gravity.CENTER }
        val sub = TextView(this).apply { text="Anglais  →  Français\n\nUn appui, puis lis ton chapitre normalement."; textSize=17f; gravity=Gravity.CENTER; setPadding(0,32,0,32) }
        status = TextView(this).apply { text="Arrêté"; gravity=Gravity.CENTER; setPadding(0,0,0,24) }
        val start=Button(this).apply { text="DÉMARRER LA TRADUCTION"; setOnClickListener { startTranslation() } }
        val stop=Button(this).apply { text="ARRÊTER"; setOnClickListener { startService(Intent(this@MainActivity, TranslationService::class.java).setAction(TranslationService.STOP)); status.text="Arrêté" } }
        root.addView(title); root.addView(sub); root.addView(status); root.addView(start, LinearLayout.LayoutParams(-1,-2)); root.addView(stop, LinearLayout.LayoutParams(-1,-2)); setContentView(root)
    }
    private fun startTranslation() {
        if (!Settings.canDrawOverlays(this)) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); Toast.makeText(this,"Autorise « afficher par-dessus les autres applis », puis appuie à nouveau sur Démarrer.",Toast.LENGTH_LONG).show(); return }
        val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(mgr.createScreenCaptureIntent())
    }
}
