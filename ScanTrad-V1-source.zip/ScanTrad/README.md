# ScanTrad
Application Android personnelle de traduction continue anglais → français pour scans/mangas affichés à l'écran.

## Fonctionnement
1. Ouvrir ScanTrad.
2. Appuyer sur **Démarrer la traduction**.
3. Autoriser l'affichage par-dessus les autres applications la première fois.
4. Accepter la capture d'écran Android.
5. Ouvrir le scan dans le navigateur et faire défiler normalement.
6. ScanTrad détecte les changements, applique OCR + traduction et affiche le français en overlay.

## Compilation gratuite
Ouvrir ce dossier dans Android Studio (gratuit), laisser Gradle synchroniser, brancher le téléphone Android, puis Build > Build APK(s).

## Notes V1
- Anglais → français uniquement.
- OCR latin ML Kit embarqué.
- Modèle de traduction ML Kit téléchargé lors de la première utilisation (Internet requis à ce moment-là).
- Le placement du texte est basé sur les boîtes OCR ; certains lettrages de manga très stylisés peuvent être mal reconnus.
- Android impose une confirmation de capture pour chaque nouvelle session MediaProjection.
